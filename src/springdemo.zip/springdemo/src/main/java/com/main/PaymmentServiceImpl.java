package com.main;

import org.springframework.stereotype.Component;

@Component //IOC
public class PaymmentServiceImpl implements PaymentService{ // IS-A dependency

	@Override
	public void pay(Double amount) {
		// TODO Auto-generated method stub
		System.out.println(amount);
	}

}
