package com.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new AnnotationConfigApplicationContext(com.main.AppConfig.class);
		//AccountService service = context.getBean(AccountService.class);
		AccountService service = (AccountService) context.getBean("accountService");
		service.display();
		service.getPaymentService().pay(5000.0);
	}

}
