package com.main;

public interface PaymentService {

	void pay(Double amount);
}
